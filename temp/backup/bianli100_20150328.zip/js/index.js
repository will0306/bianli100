$(function(){
	if(!getCookie("region_id") || !getCookie("shop_id")){
		selectLocate();
		$("#selectLocate .btn_close").remove();
	};
	categoryShow();
	goodsListHover_1("goods_list_1");
	$(".lazyload").lazyload({
		effect : "fadeIn"
	});
	$(".shipping_method li:first").click();
});

//璋冪敤閫夋嫨浣嶇疆灞�
function selectLocate(){
	popupShow('selectLocate');
	$.ajax({
		type: "POST",
		url: "locate.php",
		success: function(msg){
			$("#selectLocate .tbody_1").html(msg);
		}
	});
}

function popupShow(obj){
	//popup_mask的位置和显示
	var body_height = $("body").height();
	$(".popup_mask").height(body_height);
	$(".popup_mask").fadeTo('normal','0.5');
	//popup_wrap的位置和显示
	var ele = $("."+obj);
	ele.fadeIn();
	var height = ele.find(".popup_box").height();
	
	ele.offset({top:top});
	//$("html").css({overflow:"hidden"});
}

function popupHide(){
	$(".popup_wrap").fadeOut();
	$(".popup_mask").fadeOut();
	//$("html").css({overflow:"auto"});
}
popupShow("popup_mask")
$(".toggle_1").click=popupHide;

